


int rows, cols;  
int posprint = 1; 
int printcolor = 1; 
int mp_loop = 0;

int  musicsel = 1; 
int  musicselmax = 1; 
int  musiccard = 0; 
char musicstation[PATH_MAX];
char musictarget[PATH_MAX];
char musicbase[PATH_MAX];




void drawit()
{
        if (  printcolor == 1 ) ncolor_white(  );
        else if (  printcolor == 2 ) ncolor_cyan(  );
        else if (  printcolor == 3 ) ncolor_blue(  );
        else if (  printcolor == 4 ) ncolor_yellow(  );

        erase(); 
        mvprintw(5 , posprint , "NON BLOATED - TERMINAL JUKEBOX - !!!");	
        posprint++;

        if (  posprint >= cols -1 - 20 ) {posprint = 0 ; printcolor++;}
        if (  printcolor >= 5 ) printcolor = 1 ; 
}




////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
void njukebox_mplayer( char *myurl ){
      char cmdi[PATH_MAX];
       ncruncmd( " pkill mplayer " );

      strncpy( cmdi , " screen -d -m mplayer ", PATH_MAX );
      switch ( musiccard  )
      {
      case 0:
       strncat( cmdi , " -vo null -ao alsa:device=hw=0,0 " , PATH_MAX - strlen( cmdi) -1 );
       break;
      case 1:
       strncat( cmdi , " -vo null -ao alsa:device=hw=1,0 " , PATH_MAX - strlen( cmdi) -1 );
       break;
      case 2:
       strncat( cmdi , " -vo null -ao alsa:device=hw=2,0 " , PATH_MAX - strlen( cmdi) -1 );
       break;
      }

      if ( mp_loop == 1 )
      {
        strncat( cmdi , " -loop 0 " , PATH_MAX - strlen( cmdi ) -1 );
      }

      strncat( cmdi , " \"" , PATH_MAX - strlen( cmdi ) -1 );
      strncat( cmdi , myurl , PATH_MAX - strlen( cmdi ) -1 );
      strncat( cmdi , "\"" , PATH_MAX - strlen( cmdi ) -1 );
      if ( musicstation[0] != '#' ) ncruncmd( cmdi );
}










void njukebox_change(){
      char cmdi[PATH_MAX];
      musicselmax = filelinecount( "njukebox.lst" );
      if ( musicsel <= 1 ) musicsel = 1; 
      if ( musicsel >= musicselmax )  musicsel = musicselmax ; 

     strncpy( musicstation, filefetch( "njukebox.lst", musicsel ) , PATH_MAX );

     if ( strstr( musicstation, "www.radionomy.com" ) != 0 )
     {
            /// radionomy 
             strncpy( cmdi , "http://streaming.radionomy.com:8000/", PATH_MAX );
       
             strncat( cmdi, strsplit( musicstation , '/', 6  ), PATH_MAX - strlen( cmdi ) -1 );
             strncpy( musictarget , cmdi , PATH_MAX );


           strncpy( musicbase, strsplit( musicstation , '/', 6  ), PATH_MAX);
      }
      else 
      {
           // if it is a normal file or url
           strncpy( musictarget,              musicstation, PATH_MAX );
           strncpy( musicbase,  fbasename( musicstation ), PATH_MAX );
      }

      njukebox_mplayer( musictarget );
}




void  njukebox_sound_set(  char *mysndcmd ){
           char cmdi[PATH_MAX];
           char charo[PATH_MAX];
                   strncpy( cmdi , " amixer  --card  " , PATH_MAX );
                   snprintf( charo, 5 , "%d", musiccard );
                   strncat( cmdi , charo , PATH_MAX - strlen( cmdi ) -1 );
                   strncat( cmdi, "  set  ", PATH_MAX - strlen( cmdi ) -1 );
                   strncat( cmdi,  mysndcmd  , PATH_MAX - strlen( cmdi ) -1 );
                   ncruncmd( cmdi );
  }


  int drawradios = 0;


  char idata[50][PATH_MAX];
  void loadlistdb(){
     int foox=0;
     for( foox = 1 ; foox <= 50 ; foox++)
     {
       strncpy( musicstation, "",  PATH_MAX );
       strncpy( musicstation, filefetch( "njukebox.lst", foox ) , PATH_MAX );
       strncpy( idata[ foox ] , musicstation ,  PATH_MAX );
     }
  }



  void draw_radios(){
     int foox=0;
     for( foox = 1 ; foox <= rows-3 ; foox++)
     {
       strncpy( musicstation, "",  PATH_MAX );
       strncpy( musicstation, filefetch( "njukebox.lst", foox ) , PATH_MAX );
       if ( musicsel == foox )
         mvprintw( foox, 0, ">" );
	 else
         mvprintw( foox, 0, " " );
       if(  foox <= musicselmax ) 
         printw( "%s", idata[ foox ] );
     }
  }


int screenrefresh()
{
        getmaxyx( stdscr, rows, cols);
}






int main( int argc, char *argv[])
{	
        strncpy( musicstation, "", PATH_MAX );
        strncpy( musictarget, "", PATH_MAX );
        strncpy( musicbase, "", PATH_MAX );
        int ch ; 
        char fooline[PATH_MAX]; 
        char cwd[PATH_MAX]; 



    if ( argc == 2)
      if ( strcmp( argv[1] , "" ) !=  0 ) 
       if ( fexist( argv[1] ) == 2 )
             chdir( argv[ 1 ] );




        loadlistdb();

        printf( "PATH: %s \n", getcwd( cwd, PATH_MAX)  ); 
        nstartncurses_color_2(  );   // <-- this will  give you F10 
        getmaxyx( stdscr, rows, cols);
        curs_set( 0 );
        nodelay( stdscr , TRUE ); 

        int njukebox_gamover = 0;
        while( njukebox_gamover == 0 ) 
        {
             attroff( A_REVERSE ); 
             nodelay( stdscr, TRUE);
             curs_set( 0 );
             drawit();
             mvprintw(rows-1, cols-1, "X" );


             ncolor_white(  );
             attroff( A_REVERSE ); 
             ncrectangle( rows-5 , 0 , rows-1 , cols -1 );

             attron( A_REVERSE ); 
             ncrectangle( rows-1 , 0 , rows-1 , cols -1 );
             mvprintw( rows-1, 0, "[SEL:%d/%d][L:%d]   [CARD:%d] [RADIO:%s]", musicsel, musicselmax,
	     mp_loop, musiccard , musicbase );

             attroff( A_REVERSE ); 

	     if ( drawradios == 1) 
	       draw_radios();

             ch = getch(); 
             usleep( 1e5 );
             switch( ch ){
                 case 'j':
                 case KEY_GDOWN:
                 case KEY_GRIGHT:
                    musicsel++;
                    njukebox_change();
                    screenrefresh();
                    break;

                 case 'k':
                 case KEY_GUP:
                 case KEY_GLEFT:
                    musicsel--;
                    njukebox_change();
                    screenrefresh();
                    break;

                 case KEY_GFUNCF10:
                 case 'q':
                 case 'Q':
                    njukebox_gamover = 1;
		    break;




                 case KEY_GCTRLE:
                    strncpy( cwd , "", PATH_MAX );
                    color_set( 0, NULL ); 
                    nodelay( stdscr , FALSE ); 
                    strncpy( fooline , ncwin_inputbox( "INPUT STREAM", "" ), PATH_MAX );
                    if ( strcmp(  fooline  , "" ) != 0 )
                    {
                         nodelay( stdscr , TRUE ); 
                         strncpy( cwd , fooline , PATH_MAX );
			 njukebox_mplayer( cwd );
                    }
                    nodelay( stdscr , TRUE ); 
                    break;


                 case KEY_GCTRLR:
                    strncpy( cwd , "http://streaming.radionomy.com:8000/", PATH_MAX );
                    color_set( 0, NULL ); 
                    nodelay( stdscr , FALSE ); 
                    strncpy( fooline , ncwin_inputbox( "INPUT STREAM (radionomy)", "" ), PATH_MAX );
                    if ( strcmp(  fooline  , "" ) != 0 )
                    {
                         nodelay( stdscr , TRUE ); 
                         strncat( cwd , fooline , PATH_MAX - strlen( cwd ) -1 );
			 njukebox_mplayer( cwd );
                    }
                    nodelay( stdscr , TRUE ); 
                    break;






                 case '0':
                    musiccard = 0 ; 
                    njukebox_change();
                    screenrefresh();
                    break;
                 case '1':
                    musiccard = 1 ; 
                    njukebox_change();
                    screenrefresh();
                    break;
                 case '2':
                    musiccard = 2 ; 
                    njukebox_change();
                    screenrefresh();
                    break;

                case 'u':
                case '+':
                case KEY_GFUNCF12:
                case KEY_GPAGEUP:
                case '*':
                   njukebox_sound_set(   " PCM 2+ ");
                   njukebox_sound_set(   " Master 2+ ");
                   break;

                case 'd':
                case KEY_GFUNCF11:
                case KEY_GPAGEDOWN:
                case '-':
                case '/':
                   njukebox_sound_set(   " PCM 2- ");
                   njukebox_sound_set(   " Master 2- ");
                   break;

                 case 'a':
                    if ( musiccard == 0 ) 
                       ncruncmd( " alsamixer " );
                    else if ( musiccard == 1 ) 
                       ncruncmd( " alsamixer  -c 1 " );
                    else if ( musiccard == 2 ) 
                       ncruncmd( " alsamixer  -c 2 " );
                    break;

                 case 'L':
                    if ( mp_loop == 0 ) 
                       mp_loop = 1;
		    else
                       mp_loop = 0;
	            break;

                 case KEY_GCTRLL:
                   screenrefresh();
		   break;

                 case KEY_GCTRLD:
                 case 's':
		    if ( drawradios == 1 )
		      drawradios = 0;
		    else 
		      drawradios = 1;
                    break;

                 case 'v':
                    ncruncmd( " vim njukebox.lst  " );
                    break;

                 case KEY_GBACKSPACE:
                    ncruncmd( " pkill mplayer " );
                    break;
             }
        }

        nodelay( stdscr , FALSE ); 
	endwin();			/* End curses mode		  */
        printf( "PATH: %s \n", getcwd( cwd, PATH_MAX)  ); 
        printf( "njukebox: Bye! Have a good day! \n" );

	return 0;
}



